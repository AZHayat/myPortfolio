</> A Animated portfolio Website : Written in HTML | CSS | JS | </>
Features ;

- Fully animated 
- Dark and light Both themes available ( SWITCH BUTTON INTEGRATED )
- Emmersive Design
- Fully Responsive  (Android + Tablet + Pc)
-* OPEN SOURCE 


If you want to know how to get Free Hosting + SERVER + DATABASE {/} and Want to Deploy Your Site Without Any Cost 
Contact me ON INSTAGRAM  ---- @imranpgda

Hope you will find it useful;
thanks!

